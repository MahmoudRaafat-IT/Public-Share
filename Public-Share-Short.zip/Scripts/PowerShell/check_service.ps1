Get-Service -Name "wuauserv"
