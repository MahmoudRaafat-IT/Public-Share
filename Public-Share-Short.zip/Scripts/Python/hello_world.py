print("Hello, World! This is a sample snippet.")
