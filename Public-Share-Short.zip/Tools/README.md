# Tools Folder
This folder contains helpful utilities and resources to support IT tasks.
